import java.util.Arrays;
import java.util.Random;

class EstacionCarga {
    private final int[] tiemposCarga = {30, 45, 60};
    private final boolean[] modulosOcupados = new boolean[tiemposCarga.length];
    private final Random random = new Random();
    private final int FACTOR_SIMULACION = 100;

    public EstacionCarga() {
        Arrays.fill(modulosOcupados, false);
    }

    public synchronized int[] asignarModulo(int idRobot) {
        for (int i = 0; i < modulosOcupados.length; i++) {
            if (!modulosOcupados[i]) {
                modulosOcupados[i] = true;


                int tiempoEstimado = tiemposCarga[i];
                long tiempoRealSegundos = calcularTiempoReal(tiempoEstimado);

                return new int[] {i + 1, (int)tiempoRealSegundos, (int)tiempoRealSegundos * FACTOR_SIMULACION};
            }
        }
        return null;
    }

    public synchronized void liberarModulo(int numModulo) {
        modulosOcupados[numModulo - 1] = false;

        notifyAll();
    }

    private long calcularTiempoReal(int tiempoEstimado) {
        int factorRendimiento = random.nextInt(3) + 1;
        int variacionMax = tiempoEstimado / 2;
        int tiempoVariacion = random.nextInt(variacionMax + 1);

        long tiempoReal;

        if (factorRendimiento == 1) {
            tiempoReal = tiempoEstimado - tiempoVariacion;
        } else if (factorRendimiento == 3) {
            tiempoReal = tiempoEstimado + tiempoVariacion;
        } else {
            tiempoReal = tiempoEstimado;
        }

        return Math.max(1, tiempoReal);
    }
}