class Robot extends Thread {
    private final int idRobot;
    private final EstacionCarga estacion;

    public Robot(int id, EstacionCarga estacion) {
        this.idRobot = id;
        this.estacion = estacion;
    }

    @Override
    public void run() {
        System.out.println("Robot " + idRobot + " llega a la estación de carga.");

        int[] resultadoAsignacion = null;

        resultadoAsignacion = estacion.asignarModulo(idRobot);

        if (resultadoAsignacion != null) {
            int modulo = resultadoAsignacion[0];
            int tiempoSegundos = resultadoAsignacion[1];
            long tiempoMs = resultadoAsignacion[2];

            System.out.println("Robot " + idRobot + " comienza recarga en módulo " + modulo);

            try {
                Thread.sleep(tiempoMs);
            } catch (InterruptedException e) {
                System.out.println("Robot " + idRobot + " error no tiene modulos libres");
                estacion.liberarModulo(modulo);
                return;
            }

            System.out.println("Robot " + idRobot + " termina recarga en módulo " + modulo + " tras " + tiempoSegundos + " segundos");

            estacion.liberarModulo(modulo);

            System.out.println("Robot " + idRobot + " completamente operativo.");

        } else {
            System.out.println("Robot " + idRobot + " no puede cargar por modulos llenos");
        }
    }
}