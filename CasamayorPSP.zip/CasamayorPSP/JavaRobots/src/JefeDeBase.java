public class JefeDeBase {
    public static void main(String[] args) throws InterruptedException {
        final int NUM_ROBOTS = 5;
        EstacionCarga estacion = new EstacionCarga();
        Thread[] hilosRobots = new Thread[NUM_ROBOTS];

        System.out.println("Empieza el programa");


        for (int i = 0; i < NUM_ROBOTS; i++) {
            hilosRobots[i] = new Robot(i + 1, estacion);
            hilosRobots[i].start();
        }

        for (Thread robot : hilosRobots) {
            robot.join();
        }

        System.out.println("Programa finalizado");
    }
}